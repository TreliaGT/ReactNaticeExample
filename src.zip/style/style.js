'use strict';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop : 10,
        display: 'flex',
        flexDirection: 'column',
      },
      text:{
        color:'#45C3F8',
      },
      topbar: {
        alignSelf: 'stretch',
        height: 90,
        flexDirection: 'row', // row
        backgroundColor: '#097574',
        alignItems: 'center',
        justifyContent: 'space-between', // center, space-around
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 40,
        marginBottom: 80,
        display: 'flex',
      },
      whitetext:{
          color:'#fff',
      },
      whitetitle:{
        color:'#fff',
        fontWeight: 'bold' ,
        fontSize: 18,
      },
      title:{
        fontWeight: 'bold' ,
        fontSize: 18,
      }
  
});