
import React , { useState } from 'react';
import { TextInput, Text, View  } from 'react-native';
import TopBar from '../components/topbar';
import style from '../../style/style';




function Feed(props) {
    const [text, setText] = useState('');
    return (
        <View>  
            <TopBar {...props}/>
        <View style={style.container}>
             <Text style={style.title}>Welcome To Mini Game</Text>

             <TextInput
        style={{height: 40}}
        placeholder="Type here"
        onChangeText={text => setText(text)}
        defaultValue={text}
      />

      <Text style={{padding: 10, fontSize: 18}}>
        {text}
      </Text>
        </View>
        </View>
    );
  }

  export default Feed;
  