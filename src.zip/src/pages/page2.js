
import React from 'react';
import { Text, View } from 'react-native';
import TopBar from '../components/topbar';
import style from '../../style/style';

function Notifications(props) {
    return (
        <View>  
            <TopBar {...props}/>
      <View style={style.container}>
        <Text>Notifications Screen</Text>
      </View>
      </View>
    );
  }

  export default Notifications;
  