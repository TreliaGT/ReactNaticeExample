import React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import TopBar from './topbar';
import {
    createDrawerNavigator,
    DrawerContentScrollView,
    DrawerItemList,
    DrawerItem,
  } from '@react-navigation/drawer';

import Feed from '../pages/home';
import Notifications from '../pages/page2';

  
  function CustomDrawerContent(props) {
    return (
      <DrawerContentScrollView {...props}>
        <DrawerItem
          label="Close"
          onPress={() => props.navigation.closeDrawer()}
        />
        <DrawerItemList {...props} />
      </DrawerContentScrollView>
    );
  }

  const Drawer = createDrawerNavigator();
  
  class MyDrawer extends React.Component {
    render() {
        return ( 
            <NavigationContainer>
                 <Drawer.Navigator drawerPosition="right" drawerContent={props => <CustomDrawerContent {...props} />}>
                    <Drawer.Screen name="Home" component={Feed} />
                    <Drawer.Screen name="Notifications" component={Notifications} />
                </Drawer.Navigator>
            </NavigationContainer>
        );
    }
  }

  export default MyDrawer;