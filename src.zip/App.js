import React from 'react';
import MyDrawer from './src/components/drawer';



export default function App() {
  return (  
      <MyDrawer />
    
  );
}



